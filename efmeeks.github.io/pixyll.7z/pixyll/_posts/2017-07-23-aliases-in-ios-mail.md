---
layout: post
title: "iOS Mail Aliases"
date:   2017-07-23 12:00:00
categories: posts
---

How to properly set up email aliases in the stock iOS Mail App

## Generate an App Password for iOS Mail

1. Go to your [Google Security settings](https://myaccount.google.com/security#signin)
2. Under *Signing in to Google*, click *App Passwords*
3. If prompted for your password, enter it
4. Under *Select App*, choose *Mail*
5. Under *Select Device*, choose *Other (Custom Name)*
6. Enter a name for the app. I used *iOS Mail App*
7. Click *Generate*
8. Copy and paste this password somewhere because we will need it later


## Configure iOS Mail

1. Open *Settings* > *Mail* > *Add Account* > *Other* > *Add Mail Account*

2. Enter your information
   ```
   Name:        John Doe
   Email:       john.doe@gmail.com
   Password:    top$ecret
   Description: Gmail
   ```

3. For Incoming Mail, enter the following
   ```
   Host Name:	imap.gmail.com
   User Name:	john.doe@gmail.com
   Password:	[ Generated App Password ]
   ```

4. For Outgoing Mail, I use [smtp2go](http://www.smtp2go.com), but you can also use Gmail's SMTP server
   ```
   Host Name:	smtp.gmail.com
   User Name:	john.doe@gmail.com
   Password:	[ Generated App Password ]
   ```

You're all set!

If you would like to use Google Calendar via the iOS Calendar App, just add an account and choose Gmail. Sign in with your usual Gmail address and password. Once the account is set up, go back into the settings and tap the green toggle next to Mail to turn it off, but leave the Calendar toggle on.
