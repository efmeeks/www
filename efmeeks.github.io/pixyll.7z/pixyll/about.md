---
layout: about
title: Eric who?
permalink: "/about/"
tags: about
---
<table>
  <tr>
    <td class="selfie">
      <p>
        <img src="/images/me.png">
      </p>
    </td>
    <td class="about">
      <h2>Hello World!</h2>
      <p>I'm Eric. I am a Spanish/English interpreter and Systems Administrator living in East Texas. In my free time I play drums in a band called <a href="http://babe.band" target="_new">Babe</a> and enjoy solving problems by way of design and pragmatism.</p>
      <p>I am reachable by <a href="/contact/">Email</a>, <a href="http://twitter.com/ericfmeeks" target="_new">Twitter</a>, and <a href="http://www.t.me/ericmeeks" target="_new">Telegram</a>.</p>    
    </td>
  </tr>
</table>
