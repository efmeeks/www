<center>
  <p>
    <h1>The personal website of Eric Meeks</h1>
  </p>
  <p>
    <img src="/images/efm.io-ss.png">
  </p>
  <p>
    <small>
      Theme crafted with &lt;3 by <a href="http://johnotander.com">John Otander</a> (<a href="https://twitter.com/4lpine">@4lpine</a>).<br/>
      &lt;/&gt; available on <a href="https://github.com/johnotander/pixyll">GitHub</a>.
    </small>
  </p>
  </small>
</center>
